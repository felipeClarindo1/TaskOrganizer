import { useEffect } from 'react'
import './App.css'
import { Card } from './components/card';
import './components/card';
import './components/cardContainer.css';
import './components/buttons.css';
import './components/taskModifiction.css';
import { useTaskData } from './hooks/useTaskData';



export function App() {
  const { data } = useTaskData();

  useEffect(() => {
    var el = document.getElementById('cardBlock')!
    el.addEventListener('wheel', (event) => {
      event.preventDefault();

      el.scrollBy({
        left: event.deltaY < 0 ? -30 : 30,
      });
    });
  }, [])


  return (

    <div className='container'>
      <div className='mainTitle'><h1>MY TASKS</h1></div>
      <div className='cardContainer' id='cardBlock'>
        <div className='cardBlock' >
          {data?.map((TaskData: { name_task: string; description_task: string; start_task: Date; prevision_task: Date; completion_task: Date }) => <Card name_task={TaskData.name_task} description_task={TaskData.description_task} start_task={TaskData.start_task} prevision_task={TaskData.prevision_task} completion_task={TaskData.completion_task} />)}
        </div>

      </div>

      <button className="btn" type="button">
        <strong>New Task</strong>
        <div id="container-stars">
          <div id="stars"></div>
        </div>

        <div id="glow">
          <div className="circle"></div>
          <div className="circle"></div>
        </div>
      </button>
      <div className='windowModifiction'>

      </div>
<footer>
  
</footer>
    </div>



  )



}



