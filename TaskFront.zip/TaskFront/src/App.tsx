import { useState } from 'react'
import './App.css'
import { Card } from './components/card';
import { useTaskData } from './hooks/useTaskData';

export function App() {
  const {data} = useTaskData();
 

  return (
    
      <div className='container'>
        <h1>My Tasks</h1>
        <div className='card-grid'>
          {data?.map((TaskData: { name_task: string; description_task: string; start_task: Date; prevision_task:Date;completion_task:Date }) => <Card name_task={TaskData.name_task} description_task={TaskData.description_task} start_task={TaskData.start_task} prevision_task={TaskData.prevision_task} completion_task={TaskData.completion_task}/>)}
        </div>
        </div>
    
  )



}



