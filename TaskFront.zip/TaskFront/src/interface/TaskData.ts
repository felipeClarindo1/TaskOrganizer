export interface Task {
    id : number;
    name_task: string;
    description_task: string;
    start_task: Date;
    prevision_task: Date;
    completion_task: Date;
}