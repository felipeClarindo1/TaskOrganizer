import "./card.css"

interface CardProps{
    start_task : Date,
    prevision_task : Date,
    completion_task : Date,
    name_task : string,
    description_task : string
}

export function Card({description_task,name_task,completion_task,prevision_task,start_task}: CardProps) {
  return (
    <div className="card">
      
      <h2>{name_task}</h2>
      <p>
        <b>Valor:</b> {start_task.toLocaleString()}
      </p>
    </div>
  );
}