import "./card.css"

interface CardProps {
  start_task: Date,
  prevision_task: Date,
  completion_task: Date,
  name_task: string,
  description_task: string
}

export function Card({ description_task, name_task, completion_task, prevision_task, start_task }: CardProps) {
  return (

    <div className='card'>
      <div className='img-container'>
        <div className='img'>
          <div className="ajuste">
            <p><b>{name_task}</b></p>
            <p>{description_task}</p>
            <p>
              <b>Data de inicio:</b> {new Date(start_task.toString()).toLocaleDateString()}
            </p>
            <p>
              <b>Data prevista:</b> {new Date(prevision_task.toString()).toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>
      <div className='description'>
         <b>Conclusão:</b> {new Date(completion_task.toString()).toLocaleDateString()}
      </div>

    </div>


  );
}